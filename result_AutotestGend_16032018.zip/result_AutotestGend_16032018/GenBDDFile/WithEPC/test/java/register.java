import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Register {
@Given("^Information of required fields are ([^\"]*) , ([^\"]*), ([^\"]*), ([^\"]*), ([^\"]*)$")
public void givenFunction(String lastName, Int age, String pass, String email, String firstName){

}
@When("^I input valid data into required fields$")
public void whenFunction(){

}
@Then("^It should be ([^\"]*)$")
public void thenFunction(String result){

}
$")
public void Function(){

}
Examples:$")
public void examples:Function(){

}
|lastName|result|age|pass|user|email|firstName|$")
public void |lastname|result|age|pass|user|email|firstname|Function(){

}
|xBc6zL|FAIL|17|6UpR47o|Mmv9mQTUP9N|lJWJGnr4PtF|xkJW0n|$")
public void |xbc6zl|fail|17|6upr47o|mmv9mqtup9n|ljwjgnr4ptf|xkjw0n|Function(){

}
|FT4zZ8x|SUCCESS|35|iaEAbdJb|xOLOYLbOXXzX|9LMwtL0JVq8@E7|4yr6e3I|$")
public void |ft4zz8x|success|35|iaeabdjb|xoloylboxxzx|9lmwtl0jvq8@e7|4yr6e3i|Function(){

}
|RqHUpKFx|SUCCESS|36|9Py7VMMPX|CnRvrEKsz0GoE|3kwUD@kpdQJR15j|dJkirvq7|$")
public void |rqhupkfx|success|36|9py7vmmpx|cnrvreksz0goe|3kwud@kpdqjr15j|djkirvq7|Function(){

}
|9XvX3muwI|SUCCESS|119|iI35jg6sUH|qs7uyiUQPPBe3i|DpVm@2gZBaKRY3qS|02mFabZgJ|$")
public void |9xvx3muwi|success|119|ii35jg6suh|qs7uyiuqppbe3i|dpvm@2gzbakry3qs|02mfabzgj|Function(){

}
|h9XTfv3N1x|SUCCESS|39|35IdyUbmKfO|IZVbmFSqHnghRfv|SXahLw5PMim4xg@1U|gspPbKKJIv|$")
public void |h9xtfv3n1x|success|39|35idyubmkfo|izvbmfsqhnghrfv|sxahlw5pmim4xg@1u|gsppbkkjiv|Function(){

}
|qDyDuUjjEQr|SUCCESS|19|i3oLwIs3RQsT|CiPoQx5IdOiR6z4F|LVgcmPpol@LF36WAgT|FMYPH49KYZc|$")
public void |qdyduujjeqr|success|19|i3olwis3rqst|cipoqx5idoir6z4f|lvgcmppol@lf36wagt|fmyph49kyzc|Function(){

}
|1D25fI7IY3KB|SUCCESS|18|yfTnGpVcqMuth|3vHOPnTZr8Ly9dUCT|qvbeFI9dA1@2CYZTMpM|dfRSVh9ybIzn|$")
public void |1d25fi7iy3kb|success|18|yftngpvcqmuth|3vhopntzr8ly9duct|qvbefi9da1@2cyztmpm|dfrsvh9ybizn|Function(){

}
|Bzj6eOg9rlYlf|SUCCESS|40|XceNkMMhiFCG6a|nIUhNben14xYiuhy2n|kfkKKupY@nEjxYRB7Gft|ql6wDIiDBbESL|$")
public void |bzj6eog9rlylf|success|40|xcenkmmhifcg6a|niuhnben14xyiuhy2n|kfkkkupy@nejxyrb7gft|ql6wdiidbbesl|Function(){

}
|BNOn3ajqhjIn4Y|SUCCESS|34|aZe7gJ3wKRZYpg2|m15rapjoe409IIaauCq|9ZJ0eAW2pL7hkGYpLgS@6|oJqpzKsCvIdmRI|$")
public void |bnon3ajqhjin4y|success|34|aze7gj3wkrzypg2|m15rapjoe409iiaaucq|9zj0eaw2pl7hkgyplgs@6|ojqpzkscvidmri|Function(){

}
|7SiNtDYh7n4szLu|SUCCESS|41|t5enwlRseOh5TNEm|OSBOJTkweWNbYzzevGxv|RS3cg@ElbOOjZ6uUQPN6BZ|VGroZX8tY9Ge7lN|$")
public void |7sintdyh7n4szlu|success|41|t5enwlrseoh5tnem|osbojtkwewnbyzzevgxv|rs3cg@elboojz6uuqpn6bz|vgrozx8ty9ge7ln|Function(){

}
|h8P7kiz9pUvJknc3|SUCCESS|65|VUArlgoGNwPvUKtqe|VE4LDC8hzDtBxst8xDl1d|MDtmaEXarok6ttZF@ui0y7N|IGqUI6CI2f7HSQVt|$")
public void |h8p7kiz9puvjknc3|success|65|vuarlgognwpvuktqe|ve4ldc8hzdtbxst8xdl1d|mdtmaexarok6ttzf@ui0y7n|igqui6ci2f7hsqvt|Function(){

}
|utx36Z1ROjG3xbjP0|SUCCESS|109|PiLJOD4yULitlvTDep|nlTlcciO0ZCohPT8Up9hDI|p9ya@xQb89wj1TRQbx0Ojwhn|k1clV5QdPbXnAjVHh|$")
public void |utx36z1rojg3xbjp0|success|109|piljod4yulitlvtdep|nltlccio0zcohpt8up9hdi|p9ya@xqb89wj1trqbx0ojwhn|k1clv5qdpbxnajvhh|Function(){

}
|YsXYw6f3VNfH8SyMOH|SUCCESS|59|zlCZVmvMPlQpfIDrpXz|GjjHpx8sIBz1rHQWi8yjvyn|9v0KZiy7mAwuUb@My8bo5oyQt|qUadZkOWvWSsXMp7Ak|$")
public void |ysxyw6f3vnfh8symoh|success|59|zlczvmvmplqpfidrpxz|gjjhpx8sibz1rhqwi8yjvyn|9v0kziy7mawuub@my8bo5oyqt|quadzkowvwssxmp7ak|Function(){

}
|7xhOV9wKvJ79721jyfp|SUCCESS|66|cqVeuIjZEuKywBW9CKNj|eLXW4zIq5OvXlkwkvHIs4Ozz|9ui2iCBj08FbZCkXeeJ4qwx@od|gmulAnUbjxCKcbgFIwj|$")
public void |7xhov9wkvj79721jyfp|success|66|cqveuijzeukywbw9cknj|elxw4ziq5ovxlkwkvhis4ozz|9ui2icbj08fbzckxeej4qwx@od|gmulanubjxckcbgfiwj|Function(){

}
|9jOmGeiv0uxyJs2qYXaM|SUCCESS|61|tk4MUrGp6rG4AjGT83Uul|K1ksfHq2Xucw10M7JxqKErBDQ|rS3zuAjFs@7EukCQli0S0jCAqin|XwGv49hE6jSPykZxZgQR|$")
public void |9jomgeiv0uxyjs2qyxam|success|61|tk4murgp6rg4ajgt83uul|k1ksfhq2xucw10m7jxqkerbdq|rs3zuajfs@7eukcqli0s0jcaqin|xwgv49he6jspykzxzgqr|Function(){

}
|EMjdYlaikMdU969SfwsqT|SUCCESS|60|BF0LEKmLkChA2NBowYx4jI|96a4n3FfhZyAG4Rsjdi8tzf0u8|D69lp3pqZzHzOPW0oIshr6Uu@3lO|7p0G5aI4fek3fL1aEnlOs|$")
public void |emjdylaikmdu969sfwsqt|success|60|bf0lekmlkcha2nbowyx4ji|96a4n3ffhzyag4rsjdi8tzf0u8|d69lp3pqzzhzopw0oishr6uu@3lo|7p0g5ai4fek3fl1aenlos|Function(){

}
|G4tTbChyGAaD2hI3TdLkfU|SUCCESS|64|xdX9YsSyHyScnvLP9nY88Q3|1mmq2LnasIAhNuIWbN5UgHo847u|M8KKibijqgQtD@jiJbdCbZBGZ0DX5|Na6bXw4x4XjyReEq835ew4|$")
public void |g4ttbchygaad2hi3tdlkfu|success|64|xdx9yssyhyscnvlp9ny88q3|1mmq2lnasiahnuiwbn5ugho847u|m8kkibijqgqtd@jijbdcbzbgz0dx5|na6bxw4x4xjyreeq835ew4|Function(){

}
|fBOmKNfsY7JHHZxXV7hgQat|SUCCESS|120|NRJjp2kG2FeuQumlejH5M2ev|5z67ezNVuHRvPbLRZD8oSiaQQ1Yf|Ozvu32cIStaOStOKLXLALMaX5Op@YH|RrSKUmJq8rvqxDWGCNOY408|$")
public void |fbomknfsy7jhhzxxv7hgqat|success|120|nrjjp2kg2feuqumlejh5m2ev|5z67eznvuhrvpblrzd8osiaqq1yf|ozvu32cistaostoklxlalmax5op@yh|rrskumjq8rvqxdwgcnoy408|Function(){

}
}
